
public class testingZone {
	public static void main (String args[])
	{
		
	}
	
	double entropy (AttributeList subset)
	{
		double ans = 0;
		
		
		
		return ans;
	}
}
